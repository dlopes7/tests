from concurrent.futures import ThreadPoolExecutor
import logging
import re
import os

from kubernetes import client, config
from kubernetes.client.models.v1_pod import V1Pod

from ruxit.api.base_plugin import BasePlugin
from ruxit.api.data import MEAttribute, PluginProperty, PluginMeasurement, PluginStateMetric
from ruxit.api.exceptions import ConfigException
from ruxit.api.snapshot import get_technologies
from ruxit.api.selectors import ExplicitPgiSelector

from plugin_utils import exception_logger, time_it
from rabbitmq_api import RabbitMQClient
from dynatrace_api import DynatraceAPI

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class RabbitMQKubernetes(BasePlugin):
    @time_it
    @exception_logger
    def query(self, **kwargs) -> None:

        self.queues = []
        if "queues" in self.config and self.config["queues"]:
            self.queues = self.config["queues"].split(",")

        try:
            # This is the Kubernetes client
            if "k8s-host" in self.config and self.config.get("k8s-host"):
                logger.info("Using user supplied kubernetes url and token")
                client_config = client.Configuration()
                client_config.verify_ssl = False
                client_config.host = self.config["k8s-host"]
                client_config.api_key = {"authorization": f'Bearer {self.config["k8s-token"]}'}
                api_client = client.ApiClient(client_config)
            else:
                try:
                    logger.info("Attempting to use pod service account")
                    config.load_incluster_config()
                    api_client = client.ApiClient()
                except Exception as e:
                    logger.error(f"Could not get config from pod, error: '{e}', attempting to read from config file")
                    config.load_kube_config()
                    api_client = client.ApiClient()
        except Exception as e:
            error_message = f"Could not get a kubernetes client, error: '{e}'. If kubectl is not configured, make sure API server URL and token are correct"
            raise ConfigException(error_message)

        self.v1 = client.CoreV1Api(api_client)
        dt_client = DynatraceAPI(self.config["api_url"], self.config["api_token"])

        self.associated_entity = kwargs["associated_entity"]
        self.pgi = ExplicitPgiSelector(self.associated_entity.group_instance_id)

        logger.info(f"ProcessSnapshot: {self.associated_entity}")

        # Sometimes we get other Erlang processes (type 35), test to see if we are a RabbitMQ instance
        if "rabbitmq" in get_technologies(self.associated_entity):

            entity_id = f"PROCESS_GROUP_INSTANCE-{self.associated_entity.group_instance_id:x}"
            self.logger.info(f"Asking dynatrace API for details about: {entity_id}")
            pgi_from_api = dt_client.get_process(entity_id)
            # pgi_from_api = {"metadata": {"kubernetesFullPodNames": "rabbit-server-0" } }

            if pgi_from_api is not None:
                self.logger.info(f"Getting kubernetes metadata from {pgi_from_api}")
                pod_names = pgi_from_api.metadata.get("kubernetesFullPodNames")
                if pod_names is None:
                    error_message = f"Could not find kubernetes metadata for {entity_id} in {pgi_from_api}"
                    raise ConfigException(error_message)

                logger.info(f"rabbitmq-k8s - Found pod names: {pod_names}")

                # A Kubernetes Node can have multiple RabbitMQ processes, we will monitor each one
                for i, process in enumerate(self.associated_entity.processes):
                    pid = process.pid
                    pod_name = pod_names[i % len(self.associated_entity.processes)]

                    pod = self.get_pod(pod_name)
                    if pod is not None:
                        logger.info(f'rabbitmq-k8s - Found pod "{pod.metadata.name}" with IP "{pod.status.pod_ip}"')
                        port = self.get_pod_http_port(pod)

                        if port is None:
                            logger.error(f'rabbitmq-k8s - Could not find HTTP port for pod "{pod}"')

                        else:
                            # If we get here, we have a PID, an IP and a Port to connect to RabbitMQ
                            logger.info(f"rabbitmq-k8s - Will monitor {pod_name} using IP: {pod.status.pod_ip}, Port: {port} and send the results to PID {pid}")
                            self.process_rabbitmq(RabbitMQClient(pod.status.pod_ip, port, self.config["username"], self.config["password"]), pid)

                            self.add_property("Kubernetes pod IP", pod.status.pod_ip)
                            self.add_property("Kubernetes pod port", f"{port}")

    @time_it
    @exception_logger
    def get_pod(self, pod_name) -> V1Pod:
        # We will look for Pods where the IP, Hostname or Name match the -name parameter from the RabbitMQ process
        # We cannot get a pod on a specific namespace
        if self.config.get("k8s-namespace"):
            pods = self.v1.list_namespaced_pod(self.config.get("k8s-namespace"))
        else:
            pods = self.v1.list_pod_for_all_namespaces().items

        for pod in pods:
            if pod.metadata.name == pod_name:
                return pod
        logger.warning(f'rabbitmq-k8s - Could not find a pod with IP, Name or Hostname "{pod_name}"')

    @staticmethod
    def get_pod_http_port(pod: V1Pod):
        port = None
        for container in pod.spec.containers:
            for port in container.ports:
                if port.name == "http":
                    return port.container_port
                if port is None:
                    port = 15672

        return port

    @time_it
    @exception_logger
    def process_rabbitmq(self, rabbitmq_client: RabbitMQClient, pid):
        # We call this first to get the current node name
        cluster = self.send_cluster_metrics(rabbitmq_client)

        # Each method belows makes an HTTP Request to the RabbitMQ API, so we multithread
        # It should be pretty fast because the endpoint is on a container running on localhost
        with ThreadPoolExecutor(max_workers=5) as e:
            e.submit(self.send_queue_metrics, rabbitmq_client, cluster.node, pid)
            e.submit(self.send_node_status, rabbitmq_client, cluster.node, pid)
            e.submit(self.send_connections, rabbitmq_client, cluster.node, pid)
            e.submit(self.send_node_metrics, rabbitmq_client, cluster.node, pid)
            e.submit(self.send_channel_metrics, rabbitmq_client)
            e.submit(self.send_consumer_metrics, rabbitmq_client)
            e.submit(self.send_exchange_metrics, rabbitmq_client)

    @time_it
    @exception_logger
    def send_node_status(self, rabbitmq_client: RabbitMQClient, node_name, pid):
        node_status = rabbitmq_client.node_status
        if node_status is not None:
            self.send_state_metric("node-status", node_status, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})

    @time_it
    @exception_logger
    def send_queue_metrics(self, rabbitmq_client: RabbitMQClient, node_name, pid):
        queues = rabbitmq_client.queues
        # We only want up to 100 queues, and only queues that are on this Node

        self.send_metric("cluster-queues", len(queues))
        node_queues = [queue for queue in queues if node_name in queue.node][:100]
        logger.info(f"rabbitmq-k8s - Will process {len(node_queues)} queues from node: {node_name}")
        for queue in node_queues:
            if any([re.search(pattern, queue.name) for pattern in self.queues]):
                self.send_metric("messages-ready", queue.messages_ready, dimensions={"Queue": queue.name, "rx_pid": f"{pid:X}"})
                self.send_metric(
                    "messages-unacknowledged",
                    queue.messages_unacknowledged,
                    dimensions={"Queue": queue.name, "rx_pid": f"{pid:X}"},
                )
                self.send_metric("consumers", queue.consumers, dimensions={"Queue": queue.name, "rx_pid": f"{pid:X}"})
                self.send_metric("publish", queue.publish, dimensions={"Queue": queue.name, "rx_pid": f"{pid:X}"}, metric_type="relative")
                self.send_metric(
                    "deliver-get",
                    queue.deliver_get,
                    dimensions={"Queue": queue.name, "rx_pid": f"{pid:X}"},
                    metric_type="relative",
                )
                self.send_metric("ack", queue.ack, dimensions={"Queue": queue.name, "rx_pid": f"{pid:X}"}, metric_type="relative")
            else:
                logger.info(f"Queue {queue.name} will not be monitored because it did not match regex: {self.queues}")

    @time_it
    @exception_logger
    def send_connections(self, rabbitmq_client: RabbitMQClient, node_name, pid):
        connections = rabbitmq_client.connections
        self.send_metric("cluster-connections", len(connections))

        node_connections = [connection for connection in connections if node_name in connection.node]
        blocked_connections = len(list(filter(lambda c: c.state == "bocked", node_connections)))
        self.send_metric("connections-blocked", blocked_connections, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})

    @time_it
    @exception_logger
    def send_node_metrics(self, rabbitmq_client: RabbitMQClient, node_name, pid):
        # In theory this should always return a single Node, but who knows
        nodes = [node for node in rabbitmq_client.nodes if node_name in node.name]
        for node in nodes:
            self.send_metric("mem-used", node.mem_used, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})
            self.send_metric("fd-used", node.fd_used, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})
            self.send_metric("sockets-used", node.sockets_used, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})
            self.send_metric("procs-used", node.procs_used, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})
            self.send_metric("free-disk", node.disk_free, dimensions={"Node": node_name, "rx_pid": f"{pid:X}"})

    @time_it
    @exception_logger
    def send_channel_metrics(self, rabbitmq_client: RabbitMQClient):
        channels = rabbitmq_client.channels
        self.send_metric("cluster-channels", len(channels))

    @time_it
    @exception_logger
    def send_consumer_metrics(self, rabbitmq_client: RabbitMQClient):
        consumers = rabbitmq_client.consumers
        self.send_metric("cluster-consumers", len(consumers))

    @time_it
    @exception_logger
    def send_exchange_metrics(self, rabbitmq_client: RabbitMQClient):
        exchanges = rabbitmq_client.exchanges
        self.send_metric("cluster-exchanges", len(exchanges))

    @time_it
    @exception_logger
    def send_cluster_metrics(self, rabbitmq_client: RabbitMQClient):
        cluster = rabbitmq_client.cluster
        self.send_metric("cluster-msg-ready", cluster.messages_ready, metric_type="relative")
        self.send_metric("cluster-msg-ack", cluster.ack, metric_type="relative")
        self.send_metric("cluster-msg-unack", cluster.unack, metric_type="relative")
        self.send_metric("cluster-msg-publish", cluster.publish, metric_type="relative")
        self.send_metric("cluster-msg-deliver-get", cluster.deliver_get, metric_type="relative")
        self.send_metric("cluster-msg-redeliver", cluster.redeliver, metric_type="relative")
        self.send_metric("cluster-msg-unroutable", cluster.return_unroutable, metric_type="relative")

        self.add_property("Cluster name", cluster.name)
        self.add_property("Cluster RabbitMQ version", cluster.rabbitmq_version)
        self.add_property("Cluster Erlang version", cluster.erlang_version)

        return cluster

    def add_property(self, key: str, value: str):
        prop = PluginProperty(key=key, value=value, me_attribute=MEAttribute.CUSTOM_PG_METADATA, entity_selector=self.pgi)
        self.results_builder.add_property(prop)

    def send_metric(self, key: str, value: float, dimensions=None, metric_type="absolute"):
        measurement = PluginMeasurement(key, value, entity_selector=self.pgi, dimensions=dimensions)
        if metric_type == "absolute":
            self.results_builder.add_absolute_result(measurement)
        if metric_type == "relative":
            self.results_builder.add_relative_result(measurement)

    def send_state_metric(self, key: str, value: str, dimensions=None):
        measurement = PluginStateMetric(key, value, entity_selector=self.pgi, dimensions=dimensions)
        self.results_builder.add_absolute_result(measurement)
