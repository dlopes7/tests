import os

from kubernetes import client, config
from kubernetes.client.models.v1_pod import V1Pod
from kubernetes.client.apis.core_v1_api import CoreV1Api


def main():
    import json

    with open('properties.json', 'r') as f:
        config = json.load(f)
        token = config['k8s-token']

    client_config = client.Configuration()
    client_config.verify_ssl = False
    client_config.host = 'https://192.168.205.10:6443'
    client_config.api_key = {'authorization': f'Bearer {token}'}

    api_client = client.ApiClient(client_config)

    v1 = client.CoreV1Api(api_client)

    for pod in v1.list_pod_for_all_namespaces().items:
        if 'rabbit' in pod.metadata.name.lower():
            print(pod)

    # for endpoint in v1.list_service_for_all_namespaces().items:
    #     print(endpoint)


if __name__ == '__main__':
    main()
