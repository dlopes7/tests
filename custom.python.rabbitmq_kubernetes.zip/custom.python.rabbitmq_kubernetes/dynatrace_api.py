from datetime import datetime
from typing import List, Dict

import json
import logging
import requests

default_logger = logging.getLogger(__name__)

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ProcessGroupInstance:
    def __init__(self, raw_json: Dict):
        self.id = raw_json['entityId']
        self.metadata = raw_json['metadata']

    def json(self):
        return json.dumps(self, default=lambda o: o.__dict__,
                          sort_keys=True, indent=4)

    def __str__(self):
        return f'ProcessGroupInstance({self.id})'

    def __repr__(self):
        return self.__str__()

class DynatraceAPI(object):

    def __init__(self, url: str, token: str, logger=default_logger):
        self.url = url
        if self.url.endswith('/'):
            self.url = self.url[:-1]

        self.auth_header = {'Authorization': f'Api-Token {token}'}
        self.logger = logger

    def get_process(self, entity_id):
        url = f'{self.url}/api/v1/entity/infrastructure/processes/{entity_id}'
        self.logger.debug(f'Making request to {url}')
        r = requests.get(url, headers=self.auth_header, verify=False)
        p = None
        try:
            p = ProcessGroupInstance(r.json())
        except:
            self.logger.error(f'Could not find PGI: {url}')
        return p


def main():
    from pprint import pformat

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    default_logger.addHandler(ch)
    default_logger.setLevel(logging.DEBUG)

    with open('properties.json', 'r') as f:
        config = json.load(f)

    client = DynatraceAPI(config['api_url'], config['api_token'])
    p = client.get_process('PROCESS_GROUP_INSTANCE-D9630BEDF44687A2')
    print(pformat(p.metadata))


if __name__ == '__main__':
    main()
